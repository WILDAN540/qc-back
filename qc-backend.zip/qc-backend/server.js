
const express = require("express");
const multer = require("multer");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

const storage = multer.diskStorage({
  destination: "uploads/",
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  }
});

const upload = multer({ storage });

app.post("/api/qc-checklist", upload.fields([
  { name: "foto", maxCount: 1 },
  { name: "tandaTangan", maxCount: 1 }
]), (req, res) => {
  const { namaPengguna, catatan, checklist } = req.body;
  const foto = req.files["foto"]?.[0]?.filename;
  const tandaTangan = req.files["tandaTangan"]?.[0]?.filename;

  console.log("✅ Data Checklist QC:");
  console.log("Pengguna:", namaPengguna);
  console.log("Catatan:", catatan);
  console.log("Checklist:", JSON.parse(checklist));
  console.log("Foto:", foto);
  console.log("Tanda Tangan:", tandaTangan);

  res.status(200).json({ message: "Checklist berhasil diterima!" });
});

app.listen(PORT, () => {
  console.log(`🚀 Server berjalan di http://localhost:${PORT}`);
});
